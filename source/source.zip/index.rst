.. 网页抓取词频统计 documentation master file, created by
   sphinx-quickstart on Fri Oct 11 13:38:20 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

《中台战略》读书笔记
============================================

:标题: reStructuredText语法说明

:作者:
 - Seay
 - Seay1
 - Seay2

:时间: 2019年10月11日

:概述: 这是一篇
 关于reStructuredText

 语法说明。

1.导言
---------

* 没有什么可以做的
* 但是又什么是可以问的
* 最好是都可以

2.真的目标
----------

* 谁都不知道目标
* 还有谁
* 有人知道
* 来吧，总有可行的！

3.来吧，开干了！
----------------

#. 从0到1，一定要有开始
#. 从1到2，一定会有结局
#. 会有什么就去做
#. 能做什么就去做

4.语法格式
----------

*重点(emphasis)通常显示为斜体*

**重点强调(strong emphasis)通常显示为粗体**

``行内文本(inline literal)通常显示为等宽文本，空格可以保留，但是换行不可以。``

1. 枚举列表1
#. 枚举列表2
#. 枚举列表3

(I) 枚举列表1
(#) 枚举列表2
(#) 枚举列表3

A) 枚举列表1
#) 枚举列表2
#) 枚举列表3

下面是文字块内容：
::

   这是一段文字块
   同样也是文字块
   还是文字块

这是新的一段。

下面是行块内容：
 | 这是一段行块内容
 | 这同样也是行块内容
   还是行块内容

这是新的一段。

下面是引用的内容：

    “真的猛士，敢于直面惨淡的人生，敢于正视淋漓的鲜血。”

    --- 鲁迅

..

      “人生的意志和劳动将创造奇迹般的奇迹。”

      — 涅克拉索

>>> print "This is a doctest block."
This is a doctest block.

表格样例:

+------------+------------+-----------+
| Header 1   | Header 2   | Header 3  |
+============+============+===========+
| body row 1 | column 2   | column 3  |
+------------+------------+-----------+
| body row 2 | Cells may span columns.|
+------------+------------+-----------+
| body row 3 | Cells may  | - Cells   |
+------------+ span rows. | - contain |
| body row 4 |            | - blocks. |
+------------+------------+-----------+

简单表样例:

=====  =====  ======
   Inputs     Output
------------  ------
  A      B    A or B
=====  =====  ======
False  False  False
True   False  True
False  True   True
True   True   True
=====  =====  ======

--------------------------

https://github.com/SeayXu/

这篇文章来自我的Github,请参考 reference_。

.. _reference: https://github.com/SeayXu/

更多信息参考 引用文档_

这里是其他内容

.. _引用文档:

这是引用部分的内容

这篇文章参考的是：`Quick reStructuredText`__。

.. __: http://docutils.sourceforge.net/docs/user/rst/quickref.html

第一节 介绍
===========

其他内容...

隐式链接到 `第一节 介绍`_，即可生成超链接。

这是 |logo| github的Logo，我的github用户名是:|name|。

.. |logo| image:: https://help.github.com/assets/images/site/favicon.ico
.. |name| replace:: SeayXu

::

	import easygui as gui
	import 工具箱

	def fw(u,v,c):
		return (u+v) / (1+ (u*v)/(c*c))

	c = int(gui.enterbox('请输入一个正实数：'))

	xlist = []
	ylist = []
	zlist = []

	for u in range(-c,c):
		for v in range(-c,c):
			w = fw(u,v,c)
			xlist.append(u)
			ylist.append(v)
			zlist.append(w)

	工具箱.画3d图(xlist,ylist,zlist)